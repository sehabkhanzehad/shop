<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Blocked IP Address</div>

                <div class="card-body">
                    <p>Your IP address has been blocked and you cannot access this site.</p>
                    <p>If you believe this is a mistake, please contact the administrator.</p>
                </div>
            </div>
        </div>
    </div>
</div>